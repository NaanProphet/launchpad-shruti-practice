MegaMID for Windows
v0.24
24 September 1999
ReadMe File
-------------------

.1. Introduction 
.2. System Requirements
.3. Features
.4. Getting Started
.5. Usage
.6. FAQ
.7. Release History
.8. Contact
.9. Disclaimers


.1. Introduction

MegaMID started as a MIDI player for DOS. It is now in the process of
being rewritten from scratch for Windows. It does not have as many
features as the DOS version yet, but it has a lot of potential and will
hopefully one day be much better than the DOS version ever was.

MegaMID is special - it allows you to see all the neat stuff going on
behind the scene as your MIDI file plays. For example, you can see
the instruments used, and the notes that are being played (and that's
the tip of the iceberg).


.2. System Requirements

- Windows 95/98/NT 
- Pentium Processor or compatibles 
- Any MIDI Device (with Windows driver installed) 
- RAM: As long as your OS runs 
- HDD Space: What? It's small enough to fun off a floppy disk 
- Recommended: 800x600 resolution and above 
- Recommended: 65536 or more colors 
- Optional: MIDI Input device - so that you can jam with your MIDI files


.3. Features

3.1 General 

- Windows 95/98/NT support 
- Non-MCI and non-MIDI Stream based (i.e. Primitive! Ooogah!
  But powerful and works with everything) 
- Sends all MIDI events and SysEx messages 
- Handles Type-0 (single-track) and Type-1 (multitrack) MIDI files 
- Up to 256 tracks 


3.2 Display 

- 1000+ Instrument names (GM/GS/XG) and drumkit (GM/GS/XG/SC-88) 
- Recognises drum channels in channels other than 10 
- Shows GM/GS/XG Logo when a reset of that type is detected 
- Two different note displays:
  * Bar Display
    Notes played (as vertical bars) and velocity
    (higher velocity -> brighter notes)
    Pitch bends make those vertical bars bend!!! 
    (Very nice to look at) 
  * Keyboard Display
    Notes displayed as lighted keys on a keyboard
    (higher velocity -> brighter colored keys)
    Pitch bends are shown as a vertical indicator on the right
    of each keyboard. 
- Controllers: pan, Reverb(R), Chorus(C), Modulation(M),
  Portamento(P), Sustain(S), Expression(E), Volume(V) 
- Text Messages (Title, Track names, Copyright messages etc.) 
- Tempo 
- Time 
- Maximum Polyphony 
- Debug Message Window (For looking at error messages from
  MegaMID)
- Background wallpaper - using any BMP file (any color depth or
  size); MegaMID automatically tiles it if it doesn't fill up
  the screen
- Embedded GS bitmap display
- Beat indicator (red and green running LEDs)
- Bar display (Shows current bar/measure and beat)

3.3 Control 

- Play, Stop, Pause, FF
- Change instruments; drop-down instrument lists
- Change tempo
- Mute/unmute and solo individual channels

3.4 MIDI

- Supports MIDI IN - can play along while MIDI file is playing 
- Selectable MIDI In device 
- Selectable MIDI Out device 
- Configurable MIDI Reset Type (None/Windows/GM/GS/XG) 
- Feature to remap (redirect) notes from all drum channels to
  channel 10; allows GS/XG songs which use extra drum channels
  to play properly on MIDI devices which are not fully GS/XG
  compliant
- Multiple ways of playing a MIDI file
  * Built-in MIDI file picker
  * Drag-and-drop
  * Load button
  * *.MID file association (Double-click a MID file to make
    MegaMID play it - see section 6.1)
- Lead in and lead out times when playing each file. Lead in
  allows users to give the PC time to 'stabilise' and MIDI
  instruments time to reset before playback begins. Lead out
  time allows notes to decay away at the end of playback
    

.4. Getting Started

This section tells you how to install MegaMID. It's very short.

There are no installation files. The only file you need is
MegaMID.exe - copy it anywhere you want. And just double-click
on it to run.


.5. Usage

I'll skip the more obvious stuff and just document the more subtle
features.


5.1 Control Window

This is the window with the play and stop buttons, among other things.

The "Notes" button is used to restore the Note Display Window, if
you closed it.

The "Debug" button brings up the Debug Window - for showing
debug and diagnostic messages (it's more for my use).


5.2 Drag and drop

You can drag-and-drop MIDI (*.MID) or Karaoke (*.KAR) files into
the Note Display Window or the Control Window, and MegaMID will
start playing that file. Only one file at a time is allowed - 
dragging a whole bunch of them won't work right now.


5.3 Bar and Keyboard Note Display

To switch between two, right-click in the note display area of
the Note Display window. A pop-up will allow you to switch between
the two.


5.4 Changing Tempo

Left/right-click on the tempo (bottom-left) of the Note
Display Window to decrement/increment its value. Holding down the CTRL
key while clicking it will change the value in steps of 10.

You can only change the tempo when a song is playing. These and other
changes affect only playback, and do not alter the MIDI file itself.


5.5 Changing Instruments (Program change)

Left clicking on the instrument name will produce a pop-up showing
all instruments of the same class, including those in different banks.
GS instruments are shown by default, unless XG mode is active.

Right clicking on the instrument name will produce a pop-up
of all instruments in that bank - so that you can switch quickly to
any instrument.


CTRL-Left/right-click on the instrument name for one of the 16 channels in 
the Note Display Window to decrement/increment its value. Holding down 
the SHIFT key while clicking it will change the value in steps of 10.

You can only change the instruments when a song is playing.


5.6 Reseting Changes

You can restore the original tempo and instrument settings hitting the 
BackSpace key when the Note Display window is active (to make a window
active, just click on it)


5.7 Wallpapering the background

MegaMID can place bitmaps in the Note Display Window's background. To
do that, place the BMP file in the same directory as MegaMID.exe, and
rename that BMP file to "megamid.bmp". MegaMID will load that file
the next time it is run.

The BMP can be any size and any color depth - finally... the ability
to load full-color pictures as wallpaper! (The DOS version could only use
special greyscale or 64-color images)


5.8 Remap drum channels option

Some GS/XG MIDI files convert some channels into drum channels. When these 
files are played on a non-GS/XG device (such as SB Live!), you'll get 
note-bashing on those channels instead of percussion. MegaMID has an option 
now to redirect all those notes to Channel 10 (the drum channel) so that 
they'll be played properly!


5.9 Mute/unmute and solo individual channels

Each channel has a green box to the left of its instrument name. If the box
is bright green, that channel is on. If it is dark green, it is muted (off).

To mute a channel, left-click on the green box. Left-click the green box of 
a muted channel to unmute it. Double-click on it to solo that channel.
Right-click on any green box to unmute all channels.


.6. FAQ

6.1 How do I make MegaMID my default MIDI player?

The following instructions are for Windows 98. I think it should be the 
same or similar for Windows 95 and NT.

   1.Double-click on the My Computer icon on your desktop. 
   2.Select View from the menu bar. 
   3.Select Folder Options... from the pull-down menu. 
   4.In the Folder Options window, click on the File Types tab. 
   5.Select MIDI Sequence under the Registered file types list. 
   6.Click on the Edit... button. 
   7.In the Edit File Type window, click on the New... button. 
   8.New Action window appears. In the Action box, enter Play with
     MegaMID. 
   9.In the Application used to perform action box, enter the full path of the
     MegaMID file. You can use the Browse... button to help you locate the
     MegaMID file. 
  10.Click OK to accept the new settings. 
  11.The Play with MegaMID option should appear in the Actions list now,
     together with Open and Play. Select this option. 
  12.Click on the Set Default button. 
  13.That's it!!! MegaMID will now be used to automatically play a MIDI 
     file every time you double-click on it. 

To revert back to your previous setting, select Play from the Actions list in the
Edit File Type window, and click on the Set Default button.


6.2 I have Windows 98 on my PC, and when I use MegaMID to play a MIDI file with
    lots of text, it becomes jerky.

Go to your Display Properties in your Control Panel. Click on the Effects tab.
Uncheck the box that says Animate windows, menus and lists. That should
prevent all the jerkiness.


6.3 MegaMID can sometimes be jerky if I do something else while playing back a 
    MIDI file!

Er... yes. MegaMID does not use MCI or MIDI Streaming. And it does not use a
32-bit to 16-bit thunking layer. If you don't know what that means, then I'll explain
another day :) Basically, it means that it didn't use any of the fancy tricks needed
to make the timing rock solid, but it also allows MegaMID to be very flexible in
processing MIDI information, and it allows a single version to work on all three
Windows flavours. So it can't/won't be fixed! If you need rock-solid timing, go use
any of the other hundreds of MIDI players. If you need to see neat stuff happening
in your MIDI file, use MegaMID :)


6.4 Will you port MegaMID to Linux/BeOS/OS2/MacOS/(insert favourite OS here)?

No. Sorry, but I just don't have the time.


6.5 Will MegaMID finally work on my SoundBlaster 16?

Yes! It won't sound good with FM, but you can finally hear MegaMID play thru your
SB16. And it'll work with just about anything else that can play MIDI thru Windows,
so that's just marvelous.


6.6 Will you continue to work on the DOS version?

I doubt it. I started on the DOS version a long time ago when I didn't know much
about writing large programs. MegaMID for DOS is a small program that really got
out of hand. It's a mess. And DOS is pretty dead anyway. So I think I will
concentrate on the Windows version, which was completely written from scratch
and is far easier to work on. And the Windows version has so much more
potential!!!


.7. Release History

v0.24 (24 September 99)
- Mute/unmute or solo individual channels
- Fixed bug which prevented settings from being saved in Windows NT

v0.23 (21 August 99)
- Shows GS bitmaps (in the MegaMID logo area)
- Lead in and lead out times
- Beat indicator (running red and green LEDs) - DOS version buggy, this one 'fixed' :)
- Bar and beat display
- Client area of Note Display now fixed at 640x400 - independent of size of title bar etc.
  (previous versions might have bits of the note display window obscured depending on your
  display settings)
- 3-line text display in Note Display - automatically scrolls up (sorry, no manual 
  scrolling yet)
- Disabled automatic scrolling of the Control Window text display (this can apparently tax
  the PC quite abit)
- Some minor bug fixes

v0.22 (11 August 99)
- Fixed some code that may cause MegaMID to hang when playing certain MIDI files
- Overhauled File Picker - the old version is ugly and just usable. New version
  is elegant:
  - resizable window
  - shows long filenames, icons, filesize, title of song (extracted from MIDI file)
    and date
  - file deletion (hit DEL key or the Delete button)
  - toolbar and proper directory navigation features
  - lists both *.MID and *.KAR file types
  
v0.21 (1 August 99)
- Finally added SC-88 instrument patches (I thought I did earlier but I didn't)
- Worked around a problem which causes MIDI files to play notes only at every 1
  second intervals in Windows 95 (doesn't happend in Win98/NT)
- Changed UI for changing instruments

v0.20 (28 July 99)
- Finally, interactivity! Change a MIDI file's tempo during playback
- Change the instruments too
- Drum channel remap feature (this is probably the only MIDI player to have it)
- Wallpaper support (any size and color - tiled)
- Faster screen-updating routines (makes other stuff - like keyboard displays -
  possible)
- Keyboard note display feature - finally here
- Misc cosmetic changes
- This Readme.txt file (previous versions didn't have one)
- Pause and FF controls

v0.13 (25 January 99)

- Can now make MegaMID your default MIDI player! 
- Supports drag-and-drop. Drag and drop MIDI files directly into the note
- display or control window and MegaMID will play them 

v0.12 (13 December 98)

- Supports MIDI IN - allows you to play along with your MIDI IN device while
  a MIDI file is playing 
- Made the MIDI Control window movable to the top 

 v0.11 (12 December 98)

- Recognises MIDI file type and shows the GM/GS/XG logo 
- Complete XG instrument/drumkit/SFX list - with full descriptive names
  (MU50/MU80) 
- Non GM-voices shown with different backgrounds 
- Recognises drum channels occuring in channels other than 10 
- Resizeable Note Display window 
- Does not hog MIDI OUT device anymore when MIDI playback is stopped 

v0.10 (7 December 98)

- First public release


.8. Contact
Get the latest MegaMID news and versions from:
http://web.singnet.com.sg/~litezen/megamid/

MegaMID is created by:
Fong Chee Keat (cheekeat@iname.com)

Chee Keat's a Malaysian currently working and residing in Singapore.
He picked up programming at the age of 11 for fun, and now does 
it in his work.

If you'll like to send him a postcard or anything else, do pay the
MegaMID site to get his latest address. The addresses used to be 
placed in the old "MegaMID for DOS" readme files, but they (the address)
do get obsolete at some stage.


.9. Disclaimer

For non-commercial use, this version is CardWare. If you like this 
program and continue to use it, please send the Author a postcard. This     
makes him feel that his work is appreciated and helps motivate him to
keep improving this program.

This program may be freely distributed on the conditions that it is
distributed as a whole with all accompanying files (including this one),
and that it is not sold for profit.

Please contact the Author if this program is to be used for commercial
purposes.

All trademarks used in this document are acknowledged.

This program is supplied as it is. Use it at your own risk. I will not 
be responsible for any injuries or death, computer or hard disk
crashes, loss of data, or any other disaster as a consequence, directly
or otherwise, of the usage of this program.

This program is copyrighted material. You may use it on the condition 
that it is not to be altered, hacked or reverse-engineered in
any way.