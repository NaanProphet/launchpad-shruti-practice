This is the readme file belonging to Scala version 2.44.

Scala is an editor, librarian, and analysis tool for musical tunings,
like just intonation scales, equal or historical temperaments,
non-western scales and microtonal or macrotonal scales. It allows
scales to be created, manipulated and combined in many different ways.
It can tune many different synthesizers and samplers by sending 
standard MIDI files to them. It can also modify the tuning of music in 
MIDI files, or translate MIDI files into a microtonal text score.
Users can execute their own written programs using the Scala command
language.
The Scala scale file format has become a standard for microtuning
software because of the enormous scale library and power of Scala. The
scale archive with over 4900 scales is available in a separate zip-file,
which can be unpacked by Scala.

Special requirements: none.

Freeware. Uploaded by the author.

For new users there's a file dummies.txt with an introduction to Scala.

------------------------------------------------------------

The user interface is made with the Gtk+ toolkit, see https://www.gtk.org 
and below. Some advanced functions can only be done with the command line.
Apart from the main window there are the Commands window, which shows the 
history of the commands given, and the Scale window, which shows the actual
contents of the current scale. Delve in the help file to explore the myriad
of Scala commands, see the Help menu. The Tip! function in the Help menu 
provides a lot of useful information, like definitions of scale properties 
and ways of using Scala functions and dialogs.

------------------- Installation ---------------------------

On Windows:

First download the Gtk+ Windows Runtime Environment installer available from 
https://gtk-win.sourceforge.io/home/. The version is the 32-bit 2.24.10 for 
both 32-bit and 64-bit Windows. Gtk+ 3.x is not possible yet. 
When installing it, leave the tickboxes in the additional options on, especially 
the one with the PATH variable. You can also install the GTK+ Preference Tool 
from https://gtk-win.sourceforge.io/home/index.php/Main/GTKPreferenceTool to 
change the appearance or "theme". You will also need the GTK+ Themes Package 
from https://gtk-win.sourceforge.io/home/index.php/Main/Downloads .
Then run the Scala_Setup.exe file and choose a directory, for example 
C:\Scala22 or C:\Program Files\Scala22. It can be installed in an existing 
directory overwriting a previous version. You must have administrator
privileges. Windows versions before XP are not supported.

If you get an error message about a missing entry point of libglib-2.0-0.dll,
or other error messages about dlls, your Gtk+ version is too old, or the PATH 
(environment variable) does not contain the location of the Gtk+ runtime
library. To check this, open the Windows Command Prompt and type "path" 
followed by Enter. It's also possible to have a conflict with another 
installed application that also uses Gtk+. In general it's best to have the
Gtk+ runtime library path at the beginning of the PATH variable. The Gtk+
installer puts it at the end however. Also look for Gtk things in other
locations on the computer, especially the system area \windows\system32 where 
they don't belong.

On Macintosh:

See here http://www.huygens-fokker.org/scala/downloads.html#Mac

The right mouse button normally arranges windows instead of opening a 
context menu. To optimally use Scala, let the F9 and F10 function keys not 
do window arrangement, and do not use the right mouse button for windows
expose (use the middle button instead if you want). Do this in the Expose
section of System configuration.

If you put a script named "startsynth" in the Resources folder, i.e.
/Applications/Scala.app/Contents/Resources/ then it will be run when you start
Scala. There is one in the setup package which starts SimpleSynth so you can
copy this script. Right click on Scala_Setup.app and choose show package 
contents and copy /Scala_Setup.app/Contents/Resources/nl/startsynth. Then you 
can always play sounds from Scala.

On Linux and Unix:

Please read the INSTALL file, also for using MIDI output with Scala. Please 
configure virtual MIDI ports in your system because there is no direct 
interface to Jack yet. See the Linux MIDI HOWTO at http://tldp.org/HOWTO/MIDI-HOWTO-10.html .
To get sound out of Scala, this is an easy way:
Install Aconnectgui (or Patchage which is better) and Timidity. Run 
"sudo modprobe snd-virmidi". Run Aconnectgui or Patchage and connect 
virmidi 1-0 to Timidity port 0. Run Timidity. Run Scala, go to 
Edit:Sound settings and set the MIDI output device to /dev/snd/midiC1D0.
See http://drobilla.net/software/patchage/

Then make sure that libgtkada-2.24.so.1 which is provided in the Scala 
download is accessible. You can copy this file to /usr/local/lib (as root):
% sudo cp libgtkada-2.24.so.1 /usr/local/lib
You may need to add "/usr/local/lib" to your /etc/ld.so.conf and then run
ldconfig (as root). Or add the following line to your login script (for 
example .bashrc or .profile or .cshrc etc.) if LD_LIBRARY_PATH is not 
defined yet:
export LD_LIBRARY_PATH=.:/usr/local/lib

Furthermore you also need to install the libgnat-4.6 runtime.

Gnome has disabled icons on buttons and menus by default. To enable them, 
run the following:
gconftool-2 -s -t boolean /desktop/gnome/interface/buttons_have_icons true
gconftool-2 -s -t boolean /desktop/gnome/interface/menus_have_icons true

Next, make sure that the locale setting used by X11 supports UTF-8 rather 
than only ASCII. Scala's data files are in this encoding. If you use bash 
as your shell, you can put these lines in your ~/.bashrc and ~/.profile files:
export LC_ALL=en_US.UTF-8
export LANG=en_US.UTF-8
export LANGUAGE=en_US.UTF-8

The environment variable SCALA_HOME can be set with the install
directory as value. Normally this shouldn't be necessary, but it could
help if files which Scala needs at startup cannot be found.

------------------------------------------------------------

To change the language, add a key to scala.ini like this:
Language ru
Language files are stored in the locale directory of where Gtk was
installed, for example C:\Program Files\GTK2-Runtime\share\locale on
Windows. Scala will need a scala.po file in the particular LC_MESSAGES
directory, where also the Gtk translations are stored. 
Without the Language key in scala.ini, the default system language is
used. It can be bypassed for Gtk applications by adding an environment 
variable LANG with the same language code.
A start was made with a Dutch (nl) translation but it's far from finished. 
If you're interested in making a translation for your language you may 
contact the author. It involves making a scala.po and scala.mo file. You 
will need the program msgfmt from the gettext package, see
http://www.gnu.org/software/gettext/

------------------------------------------------------------

The files with extension "par" are data files or files with parameters that
can be modified to configure Scala. Data files with official names are:
help.htm       -- contains all help text (can also be viewed with a browser).
calcval.par    -- contains interval units to express results of calculations in.
chordnam.par   -- contains chord names, in English.
editattr.par   -- contains extra attributes to be shown in the edit dialogue.
fretstr.par    -- contains list of string instrument tunings.
intmonzo.par   -- contains some interval names by Joe Monzo.
intnam.par     -- contains interval names, in English.
intnaam.par    -- contains Dutch interval names.
intname.par    -- contains German interval names.
intnom.par     -- contains French interval names.
intnomen.par   -- contains Latin interval names.
intindia.par   -- contains Indian note names.
lintemp.par    -- contains generators of linear (rank-2) temperaments.
modenam.par    -- contains scale modes, in English.
modusnam.par   -- contains Dutch mode names (rename to modenam.par).
melathat.par   -- contains Indian melas and thats (rename to modenam.par).
part.par       -- contains example partials for EXAMPLE/WAVE command.
rankntemp.par  -- contains generators of planar or higher rank temperaments.
relay.par      -- contains example to show how to trigger commands by MIDI events 
                  during MIDI relaying.
sag*.par       -- contains parameters for the notation systems beginning with
                  SA, more will be added to sag_et.par later. Updated versions 
                  may be obtained in the future from http://www.sagittal.org .
series.par     -- contains coefficients of linear recurrent series.
string.par     -- contains example string model numbers, for fret positions.
synth.par      -- contains synthesizer system exclusive codes for tuning.
tips.par       -- contains tips of the day, property definitions and some dialog
                  instructions. Can be converted to HTML in the Tip! dialog.
vosim.par      -- contains example partials for VOSIM synthesis by EXAMPLE/WAVE 
                  command.

Documentation files:
commands.txt       -- list of all Scala commands.
cmdlist.txt        -- list of example external command files (scripts).
document.html      -- frame page for reading the documentation.
dummies.txt        -- Scala introduction for dummies.
fts_and_scala.html -- how to let Scala and Fractal Tune Smithy cooperate.
helpindx.html      -- contents listing of help file.
links.html         -- contains links to other websites.
readme.txt         -- this file.
references.html    -- literature references for tuning theory behind Scala.
INSTALL            -- installation instructions (Linux/Unix only).

Other Scala input files:
diatonic.clv    -- computer keyboard mapping for diatonic note names for the clavier.
diatonicSE.clv  -- Swedish keyboard version of above file.
keymap.clv      -- example computer keyboard mapping for the clavier.
example.kbm     -- example keyboard mapping file, usable as template.
a440.kbm        -- keyboard map with A on 440 Hz and 1/1 to middle C.
bp.kbm          -- keyboard map for Bohlen-Pierce scales.
clinear.kbm     -- keyboard map with middle C on standard frequency.
61.kbm          -- keyboard map for 60-tone scale to 5-octave keyboard.
128.kbm         -- keyboard map for 127-tone scale to all keys.
black.kbm       -- keyboard map for pentatonic scale to black keys.
6.kbm           -- keyboard map for hexatonic scale.
white.kbm       -- keyboard map for heptatonic scale to white keys.
8.kbm           -- keyboard map for octatonic scale.
10.kbm          -- keyboard map for decatonic scale.
11.kbm          -- keyboard map for 11-tone scale.
two17.kbm       -- keyboard map for 17-tone scale using 24 keys.
two19.kbm       -- keyboard map for 19-tone scale using 24 keys.
two20.kbm       -- keyboard map for 20-tone scale using 24 keys.
two22*.kbm      -- keyboard maps for 22-tone scale using 24 keys.
erl22*.kbm      -- keyboard maps for 12-tone modes of 22 equal.
miller24.kbm    -- keyboard map for 24-tone scale with naturals and flats on
                   white and sharps and double sharps on black.
miller31.kbm    -- keyboard map for 31-tone scale with naturals and flats on
                   white and sharps and double sharps on black.
mr88cet.kbm     -- keyboard map for 88 cents step equal temperament.
piano.kbm       -- keyboard map for 88-tone scale to 88-key piano.
map_*.kbm       -- multichannel map for microtonal keyboard.
pbexampl.seq    -- example file for the EXAMPLE command.
*.plt           -- gnuplot input files for different plots, can be changed.
plot*.in        -- gnuplot input files determining output formats, can be changed.
*.scl           -- example scales.
scalarc         -- graphics resource file, can be edited to change fonts, 
                   colours, styles, backgrounds, etc., in addition to
                   %HOMEPATH%\.gtkrc-2.0 or $HOME/.gtkrc-2.0
scala.ini       -- initialisation file with various user parameters, can be 
                   edited when Scala is not running.
*.seq           -- pitch bend example files with compositions.
scaleplot.png, scale_plot.pdf, scaleplot.ps, scaleplot.svg etc.
                -- output files that gnuplot creates from Scala. Names can be
                   changed by editing plot*.in.
browse.cmd      -- command file for starting browser with any file. Change this
                   file to replace browser program.
help.cmd        -- command file for browsing the help file.
gnuplot.cmd, gnuplotf.cmd
                -- command files for invoking gnuplot. 
                   Edit these after installing gnuplot to invoke with the right path.
                   On windows they will be configured by the installer if gnuplot is 
                   already installed.
startup.cmd     -- example startup command file.
send.cmd        -- command file for downloading a tuning to a synthesizer.
sendm.cmd       -- command file for downloading a tuning to a synthesizer with Megamid.
shell.cmd       -- command file to open an OS shell.
timidity.cmd    -- command file to convert a (microtonal) MIDI file to a .wav
                   soundfile with Timidity (must be installed separately).
timidityplay.cmd-- command file to play a (microtonal) MIDI file with Timidity.
play.cmd        -- command file for playing a MIDI file.
cmd\playm.cmd   -- command file for playing a MIDI file under Windows with Megamid.
cmd\playlin.cmd -- command file for playing a MIDI file under Linux.
cmd\playwin.cmd -- command file for playing a MIDI file under Windows with 
                   Windows Media Player.
cmd\smithy.cmd  -- command file for playing with the current scale in Fractal 
                   Tune Smithy (Windows only).
cmd\*.cmd       -- other utility command files. Reading them is instructive.
gm1_on.mid      -- MIDI file to switch General MIDI 1 system on.
gm2_on.mid      -- MIDI file to switch General MIDI 2 system on.
gm_off.mid      -- MIDI file to switch General MIDI system 1 or 2 off.
gs_reset.mid    -- MIDI file to do a reset of a Roland device to GS initial state.
html\*.png      -- image files with graphical accidentals.
xpm\*.*         -- image files with program icons.

Included third-party software:
megamid.exe     -- Megamid 0.24 MIDI file player (Windows).
mf2tXP.zip      -- XP executables mf2tXP.exe (MIDI file to text) and 
                   t2mfXP.exe (text to MIDI file) (can be compiled on any platform, 
                   http://www.midiox.com/zip/mf2tXP-src.zip).
                   A similar program is midicsv: 
                   http://www.fourmilab.ch/webtools/midicsv/

Not-included third-party software:
gnuplot         -- Download page: http://www.gnuplot.info
                -- After installing, open the Scala files gnuplot.cmd and gnuplotf.cmd
                   in an editor and set the path to the location where it was installed.
                   Zooming in can be done with the right and left mouse button, and
                   'u' to unzoom.
                   In 3D graphs the viewing position can be changed by a left-click 
                   and moving the cursor.
                   Installation on OSX can be done with MacPorts, type in Terminal:
                   sudo port install gnuplot
                   Or with Homebrew, type in Terminal:
                   sudo brew install gnuplot
                   Installation on Ubuntu Linux by:
                   sudo apt-get install gnuplot5-x11

It is advisable to put scale files in a separate subdirectory, in order not to 
mix them with the program files. Then put the command "cd <subdirectory>" in 
startup.cmd to automatically go to that directory. 

For a little tutorial of basic commands look at tutorial.cmd and run it from the 
Scala command line with "@tutorial".

The following files are searched for in the current directory first (at program 
start or later), and next in the user's application data directory 
(%APPDATA%\Scala on Windows, ~/.Scala on Unix), so they can override the file 
in the Scala program directory. If it's not found in either of them, it's 
looked for in the directory which is specified by the environment variable 
"SCALA_HOME".

calcval.par
chordnam.par
editattr.par
gnuplot.cmd
gnuplotf.cmd
lintemp.par
play.cmd
rankntemp.par
relay.par
scala.ini
scalarc
send.cmd
startup.cmd
string.par
timidity.cmd
timidityplay.cmd

All other .cmd files are searched for in the current directory first,
and then in the scala program directory.

Windows users can associate Scala's file types .scl, .kbm and .cmd with
Scala by double-clicking on files of these types in a folder window.
Then an "Open with" dialog box appears. Enter a description:
"Scala scale file", or
"Scala keyboard mapping", or
"Scala command file".
Then click the "Other.." button and select the scala.exe program file. 
Then click on "OK". Now if these files are double-clicked on, Scala will 
start and load this file automatically. The installer for the GUI-version
takes care of this automatically. Double-clicking on files does not open 
them on Windows if any enclosing directory contains a space in the name.

------------------------------------------------------------

Recommended third-party software:

-- gnuplot (Linux, Macintosh and Windows)
Download page: http://gnuplot.sourceforge.net
Scala integrates gnuplot to create plots of scales.
-- MicroABC (Linux and Windows)
Download page: https://hudsonlacerda.webs.com
Creates scores and MIDI files from ABC microtonal notation.
-- MIDI Yoke and loopMIDI (Windows)
Download pages: http://www.midiox.com/myoke.htm and
http://www.tobias-erichsen.de/software/loopmidi.html
These are MIDI loopback programs and are useful for MIDI relaying, especially
if you don't have MIDI input devices.
-- MidiPipe (Macintosh)
Download page: https://midipipe.en.softonic.com/mac or 
http://www.subtlesoft.square7.net/MidiPipe.html 
This is a MIDI loopback program, can be used to connect Scala to a softsynth
and for MIDI relaying. A similar program is MIDI Patchbay:
https://www.macupdate.com/app/mac/7243/midi-patchbay/
-- Fractal Tune Smithy (Windows)
Download page: http://tunesmithy.co.uk
-- SimpleSynth (Macintosh)
Download page: https://mac.softpedia.com/get/Audio/SimpleSynth.shtml
-- SysEx Librarian (Macintosh)
Plays midi files.
Download page: https://www.snoize.com/SysExLibrarian/
-- Timidity (Linux, Macintosh and Windows)
Creates CD quality sound files from MIDI files with full microtonal support
Download page: http://timidity.sourceforge.net
See http://www.hammersound.net and http://freepats.zenvoid.org for free soundfonts

See also links.html for Scala documentation and other websites.

------------------------------------------------------------

In order to play a MIDI file by opening it with the Open command in
the File menu, you need to copy the appropriate play*.cmd file in the
cmd subdirectory to play.cmd in the Scala directory. This depends on 
the player you want to use. To use Scala's internal player, use the
PLAY command (Windows and Macintosh only).
If you want to change the MIDI file player, edit both the files 
send.cmd and play.cmd and fill in the filename containing the full path 
of the player's .exe file. Put it between double quotes (") if the 
pathname contains spaces. Be aware that not all midi players play 
Scala's microtuned files correctly, having bugs concerning pitch bend
messages (Please check before you ask me if something is wrong with Scala).

On the Macintosh a software synth must be started first to hear MIDI
files, for example SimpleSynth.

In the Windows distribution a MIDI file player is included, MegaMID.
It can be used to download tuning dumps to an instrument. The command 
file send.cmd calls this program from within Scala by default, but if 
you edit it, the command with SPAWN can be replaced with the command PLAY. 
Download it from https://dosprograms.info.tt/sound.htm .
Playing microtonal midi files made with Scala is best done with this 
or Scala's internal player. MegaMID also shows the notes and other MIDI 
events live on your screen. And it supports the XG and GS standard formats.

When you tune a Yamaha TX81Z, the MIDI speed must be reduced otherwise
a "buffer overrun" will occur. You can use the program Gsplay to play 
slowly, from here: https://dosprograms.info.tt/sound.htm . In the file 
tips.par there is a more elaborate description on how to tune the TX81Z.
The E-mu instruments in the Proteus 1000 and 2000 series have an
incorrectly implemented MIDI Tuning Standard bulk dump checksum,
causing them to silently ignore MTS tuning dumps. As a workaround, 
they have a special checksum value which is always accepted. This
is used with synthesizer type 113. If you're not sure about your E-mu 
instrument, try both SET SYNTH 107 and SET SYNTH 113. All microtunable
E-mu instruments are supported as far as I know.

------------------------------------------------------------

For more information about Scala, refer to the webpage
http://www.huygens-fokker.org/scala (English), or
http://www.huygens-fokker.org/scala/home-nl.html (Nederlands).

The version 1.8 for Windows 9x/NT is a console mode application. It means it 
has only a command line and looks like a DOS program but is nevertheless a 
native 32-bit Windows program. This version has no filename length limitations.
It can be downloaded from the Scala Downloads page.
The number of screen lines can be changed by resizing the window or giving the 
command SPAWN MODE CON LINES=50 (one of 25, 43, 50). Then do CLS afterwards.
The current number of columns and lines can be seen with SHOW SETTINGS. 
Linux/Unix versions automatically recognize the size of an xterm window.

The (now obsolete) version for Apple Macintosh with OSX 10.4 was made with 
advice from Hans Aberg, Kurt Bigler and Nick Dan. An even older version is here:
http://home.hccnet.nl/coul/osx/ScalaX.zip

------------------------------------------------------------

Please report bugs and problems to coul@huygens-fokker.org. Include a description
of what you were exactly doing and any error messages.
There is a GTK debugging mode you can use by starting Scala from a command
window with the command "scala --g-fatal-warnings".
If the program crashes, the current scale is put in saved.scl in the Scala 
installation directory.

------------------------------------------------------------

A large collection of scale files for Scala can be downloaded.
http://www.huygens-fokker.org/docs/scales.zip

Important: 
The scales.zip file is best opened with Scala, using File:Import scales.zip.
If not, Unix, Linux and MacOS X users should unzip the files using 
the "autoconvert" feature, to change the Windows line-breaks in the
scale files. Open an xterm or Terminal.app and type:
unzip -aa scales.zip
The scales will go to a subdirectory "scl" of the current directory.
Mac users see the bottom of this page:
http://www.huygens-fokker.org/scala/macinstall.html

They can also be used with other software, for a list see 
http://www.huygens-fokker.org/scala/scl_format.html .

------------------------------------------------------------

Ada source metrics of version 2.44p, not including the sources from 
used third-party software.

Line metrics summed over 890 units
  all lines            : 187207
  code lines           : 163078
  comment lines        : 8555
  end-of-line comments : 643
  comment percentage   : 5.35
  blank lines          : 15574

Average lines in body: 27.00

Element metrics summed over 890 units
  all statements      : 69491
  all declarations    : 42013
  logical SLOC        : 111504

 349 public types in 163 units
 including
    20 private types

 510 type declarations in 214 units

 3432 public subprograms in 347 units

 5145 subprogram bodies in 519 units

Average cyclomatic complexity: 4.49

------------------------------------------------------------

Contact the author if you want to read or compile the Ada source code.
Compiling and linking the code with other programs can be done freely
for non-commercial use.
Information about Ada can be found at https://www.adaic.org or
https://people.debian.org/~lbrenta/debian-ada-policy.html

------------------------------------------------------------

Scala was created by

Manuel Op de Coul
Muurbloemstraat 24
3053 EJ  Rotterdam
Nederland
e-mail: coul@huygens-fokker.org

Iucundi Acti Labores

Suggestions for improvements are always welcome, as is microtonal
music. Contact me for questions or in case of problems.

Scala is freeware without warranty and may not be sold, modified or
distributed for sale in combination with commercial products.
It may only be distributed as one package containing all the files 
mentioned here and for free.
------------------------------------------------------------

Copyrights of third-party software used:

-----------------------------------------------------------------------
--               GtkAda - Ada95 binding for Gtk+/Gnome               --
--                                                                   --
--   Copyright (C) 1998-2000 E. Briot, J. Brobecker and A. Charlet   --
--                Copyright (C) 2000-2006 AdaCore                    --
--                                                                   --
-- This library is free software; you can redistribute it and/or     --
-- modify it under the terms of the GNU General Public               --
-- License as published by the Free Software Foundation; either      --
-- version 2 of the License, or (at your option) any later version.  --
--                                                                   --
-- This library is distributed in the hope that it will be useful,   --
-- but WITHOUT ANY WARRANTY; without even the implied warranty of    --
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU --
-- General Public License for more details.                          --
--                                                                   --
-- You should have received a copy of the GNU General Public         --
-- License along with this library; if not, write to the             --
-- Free Software Foundation, Inc., 59 Temple Place - Suite 330,      --
-- Boston, MA 02111-1307, USA.                                       --
--                                                                   --
-----------------------------------------------------------------------

--  ________  ___   ______       ______     ___
-- /___..._/  |.|   |.___.\     /. __ .\  __|.|   ____
--    /../    |.|   |.____/     |.|__|.| /....|  __\..\
--  _/../___  |.|   |.|    ===  |..__..||. = .| | = ..|
-- /_______/  |_|  /__|        /__|  |_| \__\_|  \__\_|

-- UnZip
--------
-- This library allows to uncompress deflated, enhanced deflated,
-- imploded, reduced, shrunk and stored files from a Zip file.
--
-- Pure Ada 95 code, 100% portable: OS-, CPU- and compiler- independent.

--  Ada translation & substantial rewriting by Gautier de Montmollin
--    Web: see the Zip.web constant
--  based on Pascal version 2.10 by Abimbola A Olowofoyeku,
--    http://www.greatchief.plus.com/
--  itself based on Pascal version by Christian Ghisler,
--  itself based on C code by Info-Zip group (Mark Adler et al.)
--    http://www.info-zip.org/UnZip.html

-- Technical documentation: read appnote.txt

-- Legal licensing note:

--  Copyright (c) 1999..2009 Gautier de Montmollin

--  Permission is hereby granted, free of charge, to any person obtaining a copy
--  of this software and associated documentation files (the "Software"), to deal
--  in the Software without restriction, including without limitation the rights
--  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
--  copies of the Software, and to permit persons to whom the Software is
--  furnished to do so, subject to the following conditions:

--  The above copyright notice and this permission notice shall be included in
--  all copies or substantial portions of the Software.

--  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
--  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
--  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
--  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
--  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
--  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
--  THE SOFTWARE.

-- NB: this is the MIT License, as found 12-Sep-2007 on the site
-- http://www.opensource.org/licenses/mit-license.php

---------------------------------------------------------------------------------
--
-- EXCEL_OUT - A low level package to write Microsoft Excel (*) files
--
-- Pure Ada 95 code, 100% portable: OS-, CPU- and compiler- independent.
--

-- Legal licensing note:

--  Copyright (c) 2009 Gautier de Montmollin

--  Permission is hereby granted, free of charge, to any person obtaining a copy
--  of this software and associated documentation files (the "Software"), to deal
--  in the Software without restriction, including without limitation the rights
--  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
--  copies of the Software, and to permit persons to whom the Software is
--  furnished to do so, subject to the following conditions:

--  The above copyright notice and this permission notice shall be included in
--  all copies or substantial portions of the Software.

--  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
--  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
--  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
--  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
--  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
--  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
--  THE SOFTWARE.

-- NB: this is the MIT License, as found 12-Sep-2007 on the site
-- http://www.opensource.org/licenses/mit-license.php

-- Derived from ExcelOut @ http://www.modula2.org/projects/excelout.php
-- by Frank Schoonjans - thanks!

-- (*) All Trademarks mentioned are properties of their respective owners.
---------------------------------------------------------------------------------
